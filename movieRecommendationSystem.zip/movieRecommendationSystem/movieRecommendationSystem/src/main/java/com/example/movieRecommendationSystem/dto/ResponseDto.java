package com.example.movieRecommendationSystem.dto;

import java.io.Serializable;


import lombok.Data;

@Data

public class ResponseDto implements Serializable{
	private int status;
	private Boolean success;
	private String message;
	private Object data;


	public ResponseDto(int status, Boolean success, String message, Object data) {
		this.success = success;
		this.message = message;
		this.data = data;
		this.status = status;
	}
}
