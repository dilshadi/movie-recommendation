package com.example.movieRecommendationSystem.dto;

import lombok.Data;

@Data
public class userDto {

	private String userName;
	private String address;
	private char active;
	

}
