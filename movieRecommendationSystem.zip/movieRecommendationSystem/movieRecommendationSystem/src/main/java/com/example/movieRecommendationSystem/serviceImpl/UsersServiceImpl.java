package com.example.movieRecommendationSystem.serviceImpl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.movieRecommendationSystem.dao.IUserDao;
import com.example.movieRecommendationSystem.dto.ResponseDto;
import com.example.movieRecommendationSystem.dto.userDto;
import com.example.movieRecommendationSystem.model.Users;
import com.example.movieRecommendationSystem.service.IUserService;
@Service
public class UsersServiceImpl implements IUserService {

	@Autowired
	private IUserDao dao;

	@Override
	public ResponseDto createUser(userDto user) {
		try {
			Users users = new Users();
			BeanUtils.copyProperties(user, users);
			dao.save(users);
			return new ResponseDto(200, true, "Users Created", users);
		} catch (Exception e) {
			return new ResponseDto(500, false, "User not Created" + e, null);
		}
	}

	@Override
	public ResponseDto getAllUsers() {
		try {

			List<Users> userList = dao.findByActive('Y');
			if (!userList.isEmpty()) {
				return new ResponseDto(200, true, "Users fetch", userList);
			} else {
				return new ResponseDto(400, false, "Users not found", null);
			}
		}

		catch (Exception e) {
			return new ResponseDto(500, false, "Users not fetch" + e, null);
		}
	}

	@Override
	public ResponseDto getUsersById(Integer id) {
		try {
			Optional<Users> user = dao.findById(id);
			if (user.isPresent()) {
				return new ResponseDto(200, true, "User found", user);
			} else {
				return new ResponseDto(404, false, "User not found", null);
			}
		} catch (Exception e) {
			return new ResponseDto(500, false, "Users not fetch" + e, null);
		}
	}

	@Override
	@Transactional
	public ResponseDto deleteUsers(Integer userId) {
		dao.deleteUser(userId);
		return new ResponseDto(200, true, "User deleted", null);
	}

	@Override
	public ResponseDto updateUser(Integer userId, userDto dto) {
		try {
			Optional<Users> user = dao.findById(userId);
			if (user.isPresent()) {
				BeanUtils.copyProperties(dto, user);
				dao.save(user.get());
				return new ResponseDto(200, false, "User Updated", null);
			} else {
				return new ResponseDto(404, false, "User not found", null);
			}

		} catch (Exception e) {
			return new ResponseDto(500, false, "Users not fetch" + e, null);
		}
	}

}
