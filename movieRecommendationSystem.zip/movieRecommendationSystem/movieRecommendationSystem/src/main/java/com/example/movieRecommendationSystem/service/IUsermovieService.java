package com.example.movieRecommendationSystem.service;

import com.example.movieRecommendationSystem.dto.ResponseDto;

public interface IUsermovieService {
	public ResponseDto getMovie(String userName);

}
