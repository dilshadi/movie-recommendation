package com.example.movieRecommendationSystem.dao;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.movieRecommendationSystem.model.UserMovies;
@Repository
public interface IUserMoviesDao extends JpaRepository<UserMovies, Integer>{

	@Query("select u from UserMovies u where u.user.userName=:userName and u.createdDate=:date")
	public UserMovies isPresentByDate(String userName,Date date);
	@Query("select u from UserMovies u where u.movie=:movie and u.user.userName=:userName ")
	public UserMovies movieExist(String movie, String userName);
	
	
	
}
