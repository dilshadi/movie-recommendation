package com.example.movieRecommendationSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.movieRecommendationSystem.dto.ResponseDto;
import com.example.movieRecommendationSystem.dto.userDto;
import com.example.movieRecommendationSystem.service.IUserService;
import com.example.movieRecommendationSystem.service.IUsermovieService;

@RestController
public class UsersRestController {

	@Autowired
	public IUserService service;

	@Autowired
	public IUsermovieService movieService;

	/**
	 * create a new user
	 * 
	 * @param dto
	 * @return
	 */
	@PostMapping("create-user")
	public ResponseDto createUser(@RequestBody userDto dto) {
		return service.createUser(dto);
	}

	/**
	 * get all active users
	 * 
	 * @return
	 */
	@GetMapping("getall-user")
	public ResponseDto getAllUser() {
		return service.getAllUsers();

	}

	/**
	 * get user by id
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping("get-user-by-id/{id}")
	public ResponseDto getById(@PathVariable Integer id) {
		return service.getUsersById(id);

	}

	/**
	 * delete user
	 * 
	 * @param id
	 * @return
	 */
	@PutMapping("delete-user/{id}")
	public ResponseDto deleteUser(@PathVariable Integer id) {
		return service.deleteUsers(id);

	}

	/**
	 * update user
	 * 
	 * @param id
	 * @param dto
	 * @return
	 */
	@PutMapping("update-user/{id}")
	public ResponseDto updateUser(@PathVariable Integer id, @RequestBody userDto dto) {
		return service.updateUser(id, dto);

	}

	/**
	 * get movie api
	 * 
	 * @param userName
	 * @return
	 */
	@GetMapping("get-movie/{userName}")
	public ResponseDto getMovie(@PathVariable String userName) {
		return movieService.getMovie(userName);

	}
}
