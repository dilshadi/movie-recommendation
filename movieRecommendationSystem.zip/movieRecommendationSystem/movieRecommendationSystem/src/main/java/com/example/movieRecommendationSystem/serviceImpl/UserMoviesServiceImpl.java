package com.example.movieRecommendationSystem.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.movieRecommendationSystem.dao.IUserDao;
import com.example.movieRecommendationSystem.dao.IUserMoviesDao;
import com.example.movieRecommendationSystem.dto.ResponseDto;
import com.example.movieRecommendationSystem.model.UserMovies;
import com.example.movieRecommendationSystem.model.Users;
import com.example.movieRecommendationSystem.service.IUsermovieService;

@Service
public class UserMoviesServiceImpl implements IUsermovieService {

	@Autowired
	private IUserMoviesDao movieDao;

	@Autowired
	private IUserDao userDao;

	@Override
	public ResponseDto getMovie(String userName) {

		UserMovies newUserMovie = new UserMovies();
		Users newUser = userDao.findByUserName(userName);
		List<String> movies = new ArrayList<String>();
		movies.add("Movie1");
		movies.add("Movie2");
		movies.add("Movie3");
		movies.add("Movie4");
		movies.add("Movie5");
		String randomMovie = null;
		ResponseDto response = null;
		UserMovies userMovie = movieDao.isPresentByDate(userName, new Date());
		if (userMovie == null) {
			for (int i = 0; i < movies.size(); i++) {
				Random random_method = new Random();
				int index = random_method.nextInt(movies.size());
				randomMovie = movies.get(index);
				if (movieIsPresent(randomMovie, userName)) {
					response = new ResponseDto(400, false, "already recommended", null);
					continue;
				} else {
					newUserMovie.setMovie(randomMovie);
					newUserMovie.setUser(newUser);
					newUserMovie.setCreatedDate(new Date());
					movieDao.save(newUserMovie);
					response = new ResponseDto(200, true, "Success", randomMovie);
					break;
				}

			}

		} else {
			randomMovie = userMovie.getMovie();
			response = new ResponseDto(200, true, "Success", randomMovie);
		}

		return response;

	}

	// method to check if movie allocated to user

	public boolean movieIsPresent(String randomMovie, String userName) {
		UserMovies moviePresent = movieDao.movieExist(randomMovie, userName);
		boolean movieIsPresent = moviePresent != null ? true : false;
		return movieIsPresent;
	}

}
