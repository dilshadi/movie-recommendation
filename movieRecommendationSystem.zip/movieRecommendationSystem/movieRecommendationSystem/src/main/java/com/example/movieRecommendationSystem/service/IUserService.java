package com.example.movieRecommendationSystem.service;


import com.example.movieRecommendationSystem.dto.ResponseDto;
import com.example.movieRecommendationSystem.dto.userDto;


public interface IUserService {
	ResponseDto createUser(userDto user);
	ResponseDto getAllUsers();
	ResponseDto getUsersById(Integer id);
	ResponseDto deleteUsers(Integer userId);
	ResponseDto updateUser(Integer userId,userDto dto);

}
