package com.example.movieRecommendationSystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.movieRecommendationSystem.model.Users;
@Repository
public interface IUserDao extends JpaRepository<Users, Integer> {
     public List<Users> findByActive(char c);
     public Users findByUserName(String userName);
	@Modifying
	@Query("Update Users u set u.active='N' where u.id=:id")
	public void deleteUser(@Param(value = "id") Integer id);

}
